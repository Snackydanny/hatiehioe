(function () {
  var click = document.createElement('div');
  var body = document.getElementsByTagName('body')[0];
  body.appendChild(click);
  click.id="click";
  function bg(){click.style.backgroundImage="url(https://static.wikia.nocookie.net/cookieclicker/images/5/5a/PerfectCookie.png)";}
  bg();
}());
