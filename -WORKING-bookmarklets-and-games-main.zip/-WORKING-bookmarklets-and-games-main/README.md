# My discord server:

(https://discord.gg/Vd5sJVqVzH)

  ![Discord](http://invidget.switchblade.xyz/Vd5sJVqVzH)


# How to use:

For the bookmarklets (The ones without a .html file ending)

1. Select all of the code

2. Drag it to your bookmarks bar

3. Click when you want to run the bookmarklet

OR,

1. Copy the whole thing.

2. Type javascript: into your url bar.

3. Paste the code.

For html bookmarklets/games (The ones with a .html file ending)

1. If the view raw option is clickable, use it

2. Right click over any white space.

3. Click "Save as..."

4. Click the file when you want to use it.

For zip ones (Ones with the .zip file ending)

1. Download them

2. Double click the file until you see "main.html" or "Index.html"

3. Play it

# Me and my contributor's involvement with these:

We only made some of these, and we are not responsible for any of them. By using these, you agree to those terms. If you have a reasonable objection to something being on this repo, tell me and I'll remove it immediately.

# Other
If you have any issues or ideas, please tell me in discussions (https://github.com/dragon731012/-WORKING-bookmarklets-and-games/discussions/2).

Please enter my code 8B6M1B on fetch and get some fetch coins! https://referral.fetch.com/vvv3/referraltext?code=8B6M1B
